# MediaBox
Este es un proyecto para el curso de Desarrollo Web en CoderHouse, el cual es parte de la carrera de Full Stack

## Sobre el proyecto
MediaBox es un blog sobre entretención, como videojuegos, series, peliculas y más, este blog esta creado con la finalidad de probar y aplicar las diferentes hábilidades aprendidas a traves del curso, tecnologías como:

1. HTML5
2. CSS3
3. BOX MODELING
4. FLEXBOX
5. GRID
6. BOOTSTRAP

